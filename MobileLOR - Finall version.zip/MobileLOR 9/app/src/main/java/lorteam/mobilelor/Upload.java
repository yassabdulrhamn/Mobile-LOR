package lorteam.mobilelor;

/**
 * Created by Broookah on 12/8/2017.
 */

public class Upload {

    public String url;
    public Upload() {
    }

    public Upload(String url) {

        this.url = url;
    }



    public String getUrl() {
        return url;
    }
}
